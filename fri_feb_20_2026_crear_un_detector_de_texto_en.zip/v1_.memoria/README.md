# Memoria del Proyecto

En esta carpeta se documenta todo el histórico de decisiones, acuerdos, incidencias y memoria viva del proyecto.