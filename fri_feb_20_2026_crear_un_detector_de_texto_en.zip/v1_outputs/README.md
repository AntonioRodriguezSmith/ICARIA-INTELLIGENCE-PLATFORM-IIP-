# Carpeta de Salidas

En esta carpeta se almacenarán los resultados brutos y salidas generadas automáticamente por los procesos de la plataforma.