# ICARIA-Intelligence-Platform-1.1

**Plataforma modular para análisis y validación de casos y condiciones de negocio. Banco Sabadell // TDM/DXC**

## Objetivo
Construir y mantener una plataforma con trazabilidad total: código, datos, resultados y memoria, todo versionado y disponible para auditoría y evolución.

## Estructura prevista

```
/
├── .memoria/
├── datos/entrada/
├── docs/analisis/
├── src/
├── exportaciones/
├── plantillas/
├── outputs/
├── LICENSE
├── .gitignore
└── README.md
```

## Aviso importante

> **En caso de duda, consulta siempre `/docs/analisis/RESUMEN_GLOBAL_PROYECTO.md` y la carpeta `.memoria/` para el histórico de decisiones y documentación.**

## Responsables
- Equipo: AntonioRodriguezSmith y colaboradores de ICARIA
- Contacto: [correo electrónico o canal interno]

## Licencia
Licencia MIT. Consulta el archivo LICENSE para más información.

## Confidencialidad
Todos los datos y casos reales están protegidos como información interna y confidencial de Banco Sabadell.  
No se permite el uso no autorizado ni la divulgación externa fuera del equipo autorizado del proyecto.