### ATENCIÓN SOBRE .gitignore Y CONTROL DE DATOS

- El archivo `.gitignore` está configurado para NO excluir nunca los datos fuente, archivos de memoria ni ningún output o documentación crítica.  
- Esto garantiza que todos los casos (casos_simplificados.md), condiciones (CondicionesIcaria.txt), outputs y la memoria estén SIEMPRE versionados y disponibles en el repositorio principal, evitando pérdidas y permitiendo trazabilidad total.

> **Si tienes dudas, revisa la configuración del .gitignore antes de subir cualquier nuevo archivo a /datos/entrada/ o .memoria/**