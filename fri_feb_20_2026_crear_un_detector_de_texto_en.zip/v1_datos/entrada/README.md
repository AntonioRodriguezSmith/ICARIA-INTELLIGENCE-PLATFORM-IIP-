# Carpeta de Datos de Entrada

En esta carpeta se deben guardar los datos brutos y de entrada necesarios para los análisis y pruebas de la plataforma.