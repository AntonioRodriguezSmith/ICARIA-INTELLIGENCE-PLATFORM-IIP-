================================================================================
CASO 1
================================================================================
REQUERIMIENTO: Usuario con CCV con varias posiciones. 
               Esa CCV ha de tener una CCC asociada.

TIPO:          Particular
TyC FIRMADO:   SI
TC COMPLEJO:   SI
TC NO COMPLEJO: SI
TIPO CLIENTE:  Minorista
TITULARIDAD:   Único titular
CONFIGURABLE:  SI
ARQUETIPO:     Q48

ACCIONES EN ICARIA:
------------------
1. Usuario Particular
2. Comprobar que tenga MIFID firmado según lo establecido en la pestaña "MIFID" 
   indicado como minorista
3. Comprobar si tiene Test de Capacidad Financiera según lo establecido en la 
   pestaña "CF"
4. Comprobar si el Test de Conveniencia está realizado para productos COMPLEJOS 
   y CONVENIENTE según lo establecido en la pestaña "TC"
5. Comprobar que existe la cuenta valores en la KC11 (tabla de cuentas relacionadas)
   y enlazar la cuenta relacionada con la DV01 para verificar saldo > 1.000€ 
   (ver pestaña "KC11")
6. Verificar que la cuenta de valores tenga un solo titular (ver pestaña "TITULARES")