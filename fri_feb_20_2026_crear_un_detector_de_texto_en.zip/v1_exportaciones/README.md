# Exportaciones

Aquí se almacenan los archivos de salida que estarán preparados para entrega, informes externos o recopilaciones oficiales.