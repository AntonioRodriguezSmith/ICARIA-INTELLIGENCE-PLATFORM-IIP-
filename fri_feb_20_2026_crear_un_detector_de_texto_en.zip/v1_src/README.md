# ICARIA Intelligence Platform

Aquí irá el código fuente principal de la plataforma.