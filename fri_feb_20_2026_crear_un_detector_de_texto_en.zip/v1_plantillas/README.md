# Plantillas

Aquí se incluirán las plantillas reutilizables de código, documentación, scripts u otros elementos base para el proyecto.